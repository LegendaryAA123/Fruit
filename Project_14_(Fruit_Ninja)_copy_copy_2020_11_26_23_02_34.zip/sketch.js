var sword, swordImage, swordSound
var fruit, fruit1Image, fruit2Image, fruit3Image, fruit4Image, fruitGroup
var gameOver, gameOverImage, gameOverSound
var alien1, alien1Image, alien2Image
var score
var gameState, playState, endState

function preload(){
  swordImage = loadImage("sword.png")
  fruit1Image = loadImage("fruit1.png")
  fruit2Image = loadImage("fruit2.png")
  fruit3Image = loadImage("fruit3.png")
  fruit4Image = loadImage("fruit4.png")
  gameOverImage = loadImage("gameover.png")
  alien1Image = loadImage("alien1.png")
  alien2Image = loadImage("alien2.png")
  swordSound = loadSound("knifeSwooshSound.mp3")
  gameOverSound = loadSound("gameover.mp3")
  
 
}

function setup(){
  createCanvas(600, 600)
  sword = createSprite(300, 300, 30, 30)
  sword.addImage("sword", swordImage)
  sword.scale = 0.5
  
  fruitGroup =createGroup()
  alienGroup =createGroup()
  score = 0
  sword.setCollider("circle", 0, 0, 50)
  gameState="playState"
  gameOver = createSprite(300,300,10,10)
  gameOver.addImage("gameover", gameOverImage)
  gameOver.visible = false
}



function draw(){
  background(200)
  text("Score: "+score, 500, 30)
  drawSprites()
  if (gameState==="playState"){
  sword.y = World.mouseY
  sword.x = World.mouseX
  
  
  spawnAliens()
  spawnFruit()
  
  if (sword.isTouching(fruitGroup)){
    fruitGroup.destroyEach()
    score = score+1
    swordSound.play()
  }
  
  }
  if (sword.isTouching(alienGroup)){
    gameState="endState"
    gameOverSound.play()
  }
  if (gameState==="endState"){
    fruitGroup.destroyEach()
    alienGroup.destroyEach()
    gameOver.visible = true
  }
}

function spawnFruit(){
  if (frameCount%40 ===0){
    var side = Math.round(random(1,2))
   fruit = createSprite(650, random(50, 550), 10, 10) 
   var rand = Math.round(random(1,4))
   switch(rand) {
      case 1: fruit.addImage(fruit1Image);
              break;
      case 2: fruit.addImage(fruit2Image);
              break;
      case 3: fruit.addImage(fruit3Image);
              break;
      case 4: fruit.addImage(fruit4Image);
              break;
   }
    if (side===1){
      fruit.x = 10
      fruit.velocityX = 10+(score/4)
    }
    if (side===2){
      fruit.x = 590
      fruit.velocityX = -10-(score/4)
    }
    fruit.scale = 0.2
    fruit.lifetime = 200
    fruitGroup.add(fruit)
    
  }
}

function spawnAliens(){
  if (frameCount%100 === 0){
    var side1 = Math.round(random(1,2))
   alien1 = createSprite(550, random(50, 550), 10, 10) 
   var rands = Math.round(random(1,2))
   switch(rands) {
      case 1: alien1.addImage(alien1Image);
              break;
      case 2: alien1.addImage(alien2Image);
              break;
   }
    if (side1===1){
      alien1.x = 10
      alien1.velocityX = 10+(score/10)
    }
    if (side1===2){
      alien1.x = 590
      alien1.velocityX = -10-(score/10)
    }
    alien1.lifetime = 200
    alienGroup.add(alien1)
  }
}













